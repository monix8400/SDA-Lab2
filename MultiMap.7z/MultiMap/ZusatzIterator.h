#pragma once
#include "MultiMap.h"

class MultiMap;

class ZusatzIterator
{
	friend class MultiMap;

private:
	const MultiMap& colZ;
	//TODO - Representation

	DLLNode* ind;

	ZusatzIterator(const MultiMap& cZ);

public:

	TValue getCurrentZ()const;
	bool validZ() const;
	void nextZ();
	void firstZ();
};