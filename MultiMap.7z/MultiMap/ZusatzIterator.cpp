﻿#include "MultiMap.h"
#include "ZusatzIterator.h"

//Θ(1) ist nur wenn nur elementar Operationen sind.

//Komplexitat:
//best case: Θ(1)
//worst case: Θ(1)
//avg case: Θ(1)
ZusatzIterator::ZusatzIterator(const MultiMap& cZ) : colZ(cZ) {
	ind = cZ.map.header;
}

//Komplexitat:
//best case: Θ(1)
//worst case: Θ(1)
//avg case: Θ(1)
TValue ZusatzIterator::getCurrentZ() const {	//gibt der Knoten zuruck, wenn es ein Knoten gibt

	if (validZ() == true)
		return ind->info.second;
	return NULL_TVALUE;
}

//Komplexitat: 
//best case: Θ(1)
//worst case: Θ(1)
//avg case: Θ(1)

bool ZusatzIterator::validZ() const {	//bestimmt ob Elemente in der Liste sind, also ob die Liste leer ist

	if (colZ.isEmpty())
		return false;
	if (ind == NULL)
		return false;
	if (ind == colZ.map.header)
		return true;
	if (ind->prev != NULL)
		return true;
	return false;
}

//Komplexitat: 
//best case: Θ(1)
//worst case: Θ(1) 
//avg case: Θ(1)
void ZusatzIterator::nextZ() { //gibt der nachste Knoten zuruck

	if (ind == NULL) {
		exception e;
		throw e;
	}
	ind = ind->next;
}

//Komplexitat: 
//best case: Θ(1)
//worst case: Θ(1)
//avg case: Θ(1)
void ZusatzIterator::firstZ() { //gibt der erste Knoten zuruck

	ind = colZ.map.header;
}